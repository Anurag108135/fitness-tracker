import { render, screen } from '@testing-library/react';
import App from './App';

test('renders welcome message', () => {
  render(<App />);
  const messageElement = screen.getByText(/Welcome, Sunita Sharma/i);
  expect(messageElement).toBeInTheDocument();
});
