import React, { useState } from 'react';

function Tracker() {
  const [activity, setActivity] = useState('');
  const [activityLog, setActivityLog] = useState([]);

  const handleActivitySubmit = (e) => {
    e.preventDefault();
    if (activity.trim() === '') {
      alert('Please enter an activity');
      return;
    }
    // TODO: Add code to save the activity to the log
    setActivityLog((prevLog) => [...prevLog, activity]);
    setActivity('');
  };

  return (
    <div className="tracker">
      <h2>Track Activities</h2>
      <form onSubmit={handleActivitySubmit}>
        <div className="form-group">
          <label htmlFor="activity">Activity:</label>
          <input
            type="text"
            id="activity"
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
          />
        </div>
        <button type="submit">Add Activity</button>
      </form>
      <ul>
        {activityLog.map((activity, index) => (
          <li key={index}>{activity}</li>
        ))}
      </ul>
    </div>
  );
}

export default Tracker;
