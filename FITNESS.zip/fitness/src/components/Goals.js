import React, { useState } from 'react';

function Goals() {
  const [fitnessGoal, setFitnessGoal] = useState('');

  const handleGoalSubmit = (e) => {
    e.preventDefault();
    if (fitnessGoal.trim() === '') {
      alert('Please enter a fitness goal');
      return;
    }
    // TODO: Add code to save the fitness goal
    alert(`Fitness goal set: ${fitnessGoal}`);
    setFitnessGoal('');
  };

  return (
    <div className="goals">
      <h2>Set Fitness Goals</h2>
      <form onSubmit={handleGoalSubmit}>
        <div className="form-group">
          <label htmlFor="fitnessGoal">Fitness Goal:</label>
          <input
            type="text"
            id="fitnessGoal"
            value={fitnessGoal}
            onChange={(e) => setFitnessGoal(e.target.value)}
          />
        </div>
        <button type="submit">Set Goal</button>
      </form>
    </div>
  );
}

export default Goals;
