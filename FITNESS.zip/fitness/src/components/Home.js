import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="home">
      <h2>Welcome, Sunita Sharma!</h2>
      <p>How can we help you live a healthier life?</p>
      <Link to="/goals">Set Fitness Goals</Link>
      <Link to="/tracker">Track Activities</Link>
    </div>
  );
}

export default Home;
